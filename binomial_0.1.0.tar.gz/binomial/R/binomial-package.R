#' @import ggplot2
#' @name binomial
#' @docType package