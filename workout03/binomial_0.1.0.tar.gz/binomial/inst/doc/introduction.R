## ---- echo = FALSE, message = FALSE--------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
library(binomial)
library(ggplot2)

## ------------------------------------------------------------------------
bin_var <- bin_variable(trials = 5, prob = 0.5)
print(bin_var)

## ------------------------------------------------------------------------
summary(bin_var)

## ------------------------------------------------------------------------
bin_mean(trials = 5, prob = 0.5)
bin_variance(trials = 5, prob = 0.5)
bin_mode(trials = 5, prob = 0.5)
bin_skewness(trials = 5, prob = 0.5)
bin_kurtosis(trials = 5, prob = 0.5)

## ------------------------------------------------------------------------
bin_probability(success = 2, trials = 5, prob = 0.5)

## ------------------------------------------------------------------------
bin_choose(n = 5, k = 2)

## ---- fig.show='hold'----------------------------------------------------
bin_dis <- bin_distribution(trials = 5, prob = 0.5)
bin_dis

## ------------------------------------------------------------------------
plot(bin_dis)

## ---- fig.show='hold'----------------------------------------------------
bin_cum <- bin_cumulative(trials = 5, prob = 0.5)
bin_cum

## ------------------------------------------------------------------------
plot(bin_cum)

